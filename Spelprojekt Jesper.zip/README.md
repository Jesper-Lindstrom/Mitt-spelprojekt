The Journey

Description
The journey is a game where you play a character that meet a fox and everything that happends afterwards is the journey awaiting you!

How it plays
The game uses buttons to make 2-4 choices between the different scenes and depending on what scene will lead to 1-4 different scenarios. There is a button to toggle music that can be used after the second scene and pressing it again will mute.

How its made
My focus was writing as much javascript as possible and not pay much attention to esthetics with html and css. I've used several
functions that do the same but show different scenes and played around with boolean futures and if statements to broaden my experience with those.
